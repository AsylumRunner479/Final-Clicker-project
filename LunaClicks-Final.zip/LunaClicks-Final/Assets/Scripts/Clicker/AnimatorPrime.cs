﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatorPrime : MonoBehaviour
{
    public CharacterController controller;
    public Animator animator;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
