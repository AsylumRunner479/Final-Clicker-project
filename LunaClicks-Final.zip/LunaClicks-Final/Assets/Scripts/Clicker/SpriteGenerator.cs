﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpriteGenerator : MonoBehaviour
{
    // <access-specifier> <data-type> [] <variable-name>;
    public GameObject spritePrefab;
    //desiginates the sprite as an array that can be changed
    public Sprite[] sprites;
    // desiginates the spawnPos as an array that can be changed
    public List<Transform> spawnPos = new List<Transform>();
    //int randomIndex;

    // Update is called once per frame
    public void SpawnSprite(int index)
    {
        //may need to comment this out so you know it works
        //spawns the sprite into the world
        GameObject clone = Instantiate(spritePrefab); 
        SpriteRenderer spriteRenderer = clone.GetComponent<SpriteRenderer>();
        //chooses a sprite from the array
        spriteRenderer.sprite = sprites[index];

        int randomIndex = Random.Range(0, spawnPos.Count);
        //spawns a sheep on a spawn pos and removes it from the array
        clone.transform.position = spawnPos[randomIndex].position;
        clone.transform.localScale = new Vector3(1, 1, 1);
        Transform pointToRemove = spawnPos[randomIndex];
        spawnPos.Remove(pointToRemove);

        //sheep clone.transform.position = spawnPos[Random.Range(72, 111)].position;
        //wolf clone.transform.position = spawnPos[Random.Range(112, 151)].position;
        //star clone.transform.position = spawnPos[Random.Range(152, 191)].position;
        //farmer clone.transform.position = spawnPos[Random.Range(192, 231)].position;
        //shepherd clone.transform.position = spawnPos[Random.Range(232, 271)].position;
        //hunstman clone.transform.position = spawnPos[Random.Range(272, 311)].position;
        //astronomer clone.transform.position = spawnPos[Random.Range(312, 351)].position;

        // Spawn Prefab with Sprite Component
        // Get Sprite Component
        // Set component.sprite's value to sprites[index]
        // Instantiate(Sprite[], new Vector3(i * 2.0F, 0, 0), Quaternion.identity);
    }
}
